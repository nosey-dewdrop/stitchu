stitchu factory pack — top.shift.square.spaghetti (top)
============================================================
This is a graded production package for the studio demo recipe at its default
design parameter (extendMM = 390 mm). A factory size run
grades ONE design across the whole standard EU size chart; it does not depend on
a single shopper's custom body — a buyer picks their size from the size table.

Contents:
  manifest.json   machine-readable package (stitchu.techpack/1): size table,
                  cut list, fabric metres + weight, marker efficiency + roll
                  length, and the graded DXF file name per EU size.
  tech-pack.pdf   human-readable spec sheet (page 1 cover + cut list, page 2
                  full grade table). Every number is copied from manifest.json.
  dxf/            one DXF-AAMA/ASTM R12 interchange file per EU size. Layers:
                  1=cut boundary, 8=seamline, 7=grainline, 4=notch, 11=internal,
                  15=text. $INSUNITS=4 (millimeters). Opens in Valentina,
                  Seamly2D, ezdxf, and standard CAD.

Marker fabric width: 1400 mm.  Gramaj: 180 g/m2.
Graded sizes clean: 10/10.

Every value is computed by the deterministic stitchu engine — no LLM, no guessed
number. Same recipe + parameters -> the same package bytes.
